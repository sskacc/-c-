#define _CRT_SECURE_NO_WARNINGS 1
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	//double a = 3.0 * 3.0;
//	//double b = 4.0 * 4.0;
//	//double y = sqrt(a + b);
//	//printf("%f", y);
//	//return 0;
//	//double a = 2.0;
//	//double b = 1 - cos(3.1415926 / 3.0);
//	//double c = sqrt( b / a);
//	//double d = sin(3.1415926 / 4.0);
//	//double e = pow(d, 2.0);
//	//double f = sin(3.1415926 / 4.0) * cos(3.1415926 / 4.0);
//	//double g = cos(3.1415926 / 4.0);
//	//double h = pow(g, 2.0);
//	//double i = e + f - h;
//	//printf("%lf\n%lf", c, i);
//
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	double a = 3.0 + 6.0;
//	double b = 2.0 * sqrt(5.0) * (sqrt(6.0) + sqrt(3.0));
//	double c = b / a;
//	//���˴�Ϊ(5),cΪ���
//	double d = 3.1415926;
//	double e = sin(d / 3.0);
//	double f = log(5.0 * log(3.0)) - log(2.0);
//	double g = f / e;
//	//���˴�Ϊ(6),gΪ���
//	double h = exp(3.0) + log10(105.0);
//	printf("%lf\n%lf\n%lf", c, g, h);
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	float a = 3.0 / 4.0 + 103 % 3;
//	//(8)
//	float b = floor(3.8);
//	//(9)
//	float c = floor(-3.8);
//	//(10)
//	float e = ceil(3.2);
//	//(11)
//	float f = ceil(-3.2);
//	//(12)
//	printf("%f\n%f\n%f\n%f\n%f", a, b, c, e, f);
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//
//{
//	short a = 0;
//	int b = 0;
//	long c = 0;
//	long long d = 0;
//	unsigned int e = 0;
//
//	scanf("%hd\n%d\n%ld\n%lld\n%u", &a, &b, &c, &d, &e);
//	printf("%d\n%u\n%o\n%X\n%X", a, b, c, d, e);
//
//
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	float a = 0;
//	double b = 0;
//	scanf("%f\n%lf", &a, &b);
//	printf("%f %e\n%lf %e", a, a, b, b);
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	char a = '0';
//	scanf("%c", &a);
//	printf("%c %d %x", a, a, a);
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	int a = 0;
//	int b = 0;
//	int c = 0;
//	scanf("%d %d %d", &a, &b, &c);
//	for (int i = 1;i > 0; i++)
//	{
//		if (i % 3 == a && i % 5 == b && i % 7 == c)
//		{
//			printf("%d", i);
//			break;
//		}
//	}
//
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	int m = 0, x = 0, y = 0, z = 0, a = 0, b = 0, c = 0;
//	scanf("%d", &z);
//	for (z;z > 1; z = z - 2)
//	{
//		m++;
//		x++;
//		y++;
//		if (x == 2 && y == 4) {
//			a = a + 2;
//			y = y - 2;
//		}
//		if (x == 2 && y != 4) {
//			c++;
//			x = x - 1;
//			y++;
//		}
//		if (x != 2 && y == 4) {
//			b++;
//			y = y - 3;
//			x++;
//
//		}
//
//
//	}
//	m = m + a + b + c;
//	printf("%d %d %d %d", m, x, y, z);
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	int a = 0, b = 0,c = 0,d = 0;
//	scanf("%d", &d);
//	for (a = 1; a <= d; a++) {
//		for (b = 1; b <= a; b++) {
//			c = a * b;
//			printf("%d*%d=%d\t", b, a, c);
//		}
//		printf("\n");
//	}
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	int b = 0, d = 0;
//	double pi = 0, a = 1.0, c = 0;
//	scanf("%d", &b);
//	while ((1.0 / a) >= pow(10, -b)) {
//		
//		
//		c = pow(-1, d);
//		d++;
//		pi = pi + 4 * (1.0 / a) * c;
//		a = a + 2.0;
//	}
//	printf("%lf", pi);
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	int a[3][3] = { 0 };
//	int b[3][3] = { 0 };
//	int c[3][3] = { 0 };
//	int d[3][3] = { 0 };
//	int e[3][3] = { 0 };
//	int f[3][3] = { 0 };
//	int g[3][3] = { 0 };
//	int i = 1, j = 1, n = 1;
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			scanf("%d", &a[i][j]);
//		}
//	}
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			scanf("%d", &b[i][j]);
//		}
//	}
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			c[i][j] = a[i][j] + b[i][j];
//		}
//	}
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			printf("%d\t", c[i][j]);
//		}
//		printf("\n");//�ӷ�
//	}
//	printf("\n");
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			d[i][j] = a[i][j] - b[i][j];
//		}
//	}
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			printf("%d\t", d[i][j]);
//		}
//		printf("\n");//����
//	}
//	printf("\n");
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			e[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j];
//		}
//	}
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			printf("%d\t", e[i][j]);
//		}
//		printf("\n");//�˷�
//	}
//	printf("\n");
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			f[i][j] = a[j][i];
//		}
//	}
//	for (i = 0; i <= 2; i++) {
//		for (j = 0; j <= 2; j++) {
//			printf("%d\t", f[i][j]);
//		}
//		printf("\n");//ת��
//	}
//	printf("\n");
//	
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int max(int x, int y) {
//	if (x > y) {
//		
//}
//	if (x < y) {
//		return y;
//	}
//}
//
//int main()
//{
//	int a = 0, b = 0, c = 0, dp[100] = { 0 }, w[100] = { 0 }, v[100] = { 0 };//a,��������;b,��Ʒ��;
//	int i, j;
//	int maxw = 0, maxv = 0;
//	scanf("%d%d", &a, &b);
//	for (i = 1; i <= b; i++) {
//		scanf("%d", &w[i]);
//	}
//	for (i = 1; 1 <= b; i++) {
//		scanf("%d", &v[i]);
//	}
//	for (i = 1; i <= b; i++) {
//		for (j = 0; j <= a; j++) {
//
//		}
//	}
//	return 0;
//}

//#include<stdio.h>
//#define max 100
//
//int weight[max];
//int value[max];
//int n, max_weight, max_value;
//
//int best_answer[max], answer[max];
//
//void print()
//{
//	int i, j, k, l;
//	printf("+++++++++++++%d++++++++++++\n", max_value);
//
//	for (i = 1; i <= n; i++)
//		printf("%d ", best_answer[i]);
//	printf("\n");
//}
//
//void DFS(int level, int current_weight, int current_value)
//{
//	if (level >= n + 1)
//	{
//		if (current_value > max_value)
//		{
//			int i;
//			max_value = current_value;
//			for (i = 1; i <= n; i++)
//				best_answer[i] = answer[i];
//		}
//	}
//	else
//	{
//		if (current_weight >= weight[level + 1])
//		{
//			current_weight = current_weight - weight[level + 1];
//			current_value = current_value + value[level + 1];
//			answer[level + 1] = 1;
//			DFS(level + 1, current_weight, current_value);
//			answer[level + 1] = 0;
//			current_weight = current_weight + weight[level + 1];
//			current_value = current_value - value[level + 1];
//		}
//		DFS(level + 1, current_weight, current_value);
//	}
//}
//
//void init()
//{
//	int i, j, k, l;
//	max_value = 0;
//	for (i = 1; i <= n; i++)
//		answer[i] = 0;
//}
//
//int main()
//{
//	int i, j, k, l;
//	while (scanf("%d%d",&max_weight) != EOF, &n)
//	{
//		for (i = 1; i <= n; i++)
//			scanf("%d", &weight[i]);
//		for (j = 1; j <= n; j++)
//			scanf("%d", &value[j]);
//
//		init();
//
//		DFS(0, max_weight, 0);
//
//		print();
//
//
//	}
//	return 0;
//



//#include<stdio.h>
//#include<math.h>
//
//int main()
//{
//	int a = 0, b = 0, c = 0 ;
//	float vw[100] = { 0 }, w[100] = { 0 }, v[100] = { 0 };//a,��������;b,��Ʒ��;
//	int i, j;
//	int maxw = 0, maxv = 0;
//	scanf("%d%d", &a, &b);
//	for (i = 1; i <= b; i++) {
//		scanf("%d", &w[i]);
//	}
//	for (i = 1; 1 <= b; i++) {
//		scanf("%d", &v[i]);
//	}
//	for (i = 1; 1 <= b; i++) {
//		vw[i] = v[i] / w[i];
//	}
//
//	return 0;
//}
#define _CRT_SECURE_NO_WARNINGS .1 
#include<stdio.h>
#include<math.h>
int a[100];//�۸�
int b[100];//����
int books[100];
int n = 0;//����
int i = 0;//ѭ��
int w = 0;//����
int max = 0;//�۸�
int sum = 0;
int sum2 = 0;
int h = 0;
int max2 = 0;//����
int book[100] = { 0 };
int x = 0;
int y = 0;
int u = 0;
int main()
{   scanf("%d", &w);
	scanf("%d", &n);
	for (i = 0; i < n; i++){
		scanf("%d", &b[i]);
	}
	for (i = 0; i < n; i++){
		scanf("%d", &a[i]);
	}
	for (i = 1; i <= pow(2, n); i++){
		u = i;
		for (h = 0; h < n; h++){
			book[h] = u % 2;
			u = u / 2;
		}
		for (x = 0; x < n; x++){
			if (book[x] != 0){
				sum = sum + b[x];
				sum2 = sum2 + a[x];
			}
		}
		if (sum > w){
			sum = 0;
			sum2 = 0;
			continue;
		}
		if (sum2 <= max){
			sum = 0;
			sum2 = 0;
		}
		if (sum <= w && sum2 > max){
			max2 = sum;
			max = sum2;
			sum = 0;
			sum2 = 0;
			for (y = 0; y < n; y++){
				books[y] = book[y];
			}
		}
	}
	for (i = 0; i < n; i++)
	{
		if (books[i] != 0)
		{
			printf("%d ", i + 1);
		}
	}
	printf("%d %d", max2, max);
	return 0;
}
