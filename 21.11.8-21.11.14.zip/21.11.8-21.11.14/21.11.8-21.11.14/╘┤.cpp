#define _CRT_SECURE_NO_WARNINGS 1
//#include<stdio.h>
//int main()
//{
//	int a = 0, b = 0, c = 0, d = 0;
//	char str[1000] = { 0 };
//	char e = 0;
//	scanf("%d", &a);
//	c = getchar();
//	for (b = 0; b < a; b++) {
//		scanf("%[^\n]", str);
//		c = getchar();
//		printf("%s\n", str);
//	}
//	return 0;
//}
//#include<stdio.h>
//int main()
//{
//	char str[100] = { 0 };
//	int a = 0;
//	scanf("%s", str);
//	for (a = 1; a <= 100; a++) {
//		if (str[a] == '\0') {
//			if (str[a - 1] == 'y') {
//				str[a - 1] = 'i';
//				str[a] = 'e';
//				str[a + 1] = 's';
//			}
//			else if (str[a - 1] == 'h') {
//				 if (str[a - 2] == 'c' || str[a - 2] == 's') {
//					str[a] = 'e';
//					str[a + 1] = 's';
//				 }
//				 else {
//					str[a] = 's';
//				 }
//			}
//			else if (str[a - 1] == 's' || str[a - 1] == 'x'||str[a - 1] == 'o') {
//				str[a] = 'e';
//				str[a + 1] = 's';
//			}
//			else {
//				str[a] = 's';
//			}
//			printf("%s", str);
//			break;
//		}
//	}
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//#include<string.h>
////int main()
//{
//	int a, b, c, d = 1, e = 0, f = 0, g, h, i = 1;
//	char arr[17] = { '0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f' };
//	char str[100] = { 0 };
//	char w[100] = "0";
//	scanf("%d%d%d", &a, &b, &c);
//
//	g = c;
//	 
//		while (c != 0) {
//			d = c % 10;
//			c = c / 10;
//			e += d * pow(a, f);
//			f++;
//		}
//		if (b != 16) {
//		while (c != 0) {
//			d = c % b;
//			c = c / b;
//			e += d * pow(a, f);
//			f++;
//		}
//
//		printf("%d", e);
//	}
//	else {
//			while (c != 0) {
//				d = c % 10;
//				c = c / 10;
//				e += d * pow(a, f);
//				f++;
//		}
//		while(f > 0) {
//			i = g % b;
//			g = g / b;
//			str[f-1] = arr[i];
//			w[f-1] = str[f-1];
//			f--;
//		}
//		printf("%s", w);
//	}
//	
//	return 0;
//}
//#include<stdio.h>
//int main() {
//	char str[2] = { '0','2' };
//	char arr[2] = { 0 };
//	arr[1] = str[1];
//	printf("%c", arr[1]);
//}
//#include<stdio.h>
//#include<math.h>
//int main() {
//	int a, v, d, e = -1, f = 0, g = 0, i;
//	char x[100], c[100];
//	scanf("%d %d %s", &A, &B, c);
//	d = 0;
//	for (i = 0; c[i] != '\0'; i++) {
//		if (c[i] == '0') {
//			d = 0;
//		}
//		if (c[i] == '1') {
//			d = 1;
//		}
//		if (c[i] == '2') {
//			d = 2;
//		}
//		if (c[i] == '3') {
//			d = 3;
//		}
//		if (c[i] == '4') {
//			d = 4;
//		}
//		if (c[i] == '5') {
//			d = 5;
//		}
//		if (c[i] == '6') {
//			d = 6;
//		}
//		if (c[i] == '7') {
//			d = 7;
//		}
//		if (c[i] == '8') {
//			d = 8;
//		}
//		if (c[i] == '9') {
//			d = 9;
//		}
//		if (c[i] == 'a') {
//			d = 10;
//		}
//		if (c[i] == 'b') {
//			d = 11;
//		}
//		if (c[i] == 'c') {
//			d = 12;
//		}
//		if (c[i] == 'd') {
//			d = 13;
//		}
//		if (c[i] == 'e') {
//			d = 14;
//		}
//		if (c[i] == 'f') {
//			d = 15;
//		}
//		f *= a;
//		f += d;
//	}
//	d = f;
//	for (i = 0; d > 0; i++) {
//		e++;
//		f = d % B;
//		d /= B;
//		{
//			if (f == 0) {
//				x[i] = '0';
//			}
//			if (f == 1) {
//				x[i] = '1';
//			}
//			if (f == 2) {
//				x[i] = '2';
//			}
//			if (f == 3) {
//				x[i] = '3';
//			}
//			if (f == 4) {
//				x[i] = '4';
//			}
//			if (f == 5) {
//				x[i] = '5';
//			}
//			if (f == 6) {
//				x[i] = '6';
//			}
//			if (f == 7) {
//				x[i] = '7';
//			}
//			if (f == 8) {
//				x[i] = '8';
//			}
//			if (f == 9) {
//				x[i] = '9';
//			}
//			if (f == 10) {
//				x[i] = 'a';
//			}
//			if (f == 11) {
//				x[i] = 'b';
//			}
//			if (f == 12) {
//				x[i] = 'c';
//			}
//			if (f == 13) {
//				x[i] = 'd';
//			}
//			if (f == 14) {
//				x[i] = 'e';
//			}
//			if (f == 15) {
//				x[i] = 'f';
//			}}
//	}
//	{
//		for (i--; i >= 0; i--) {
//			printf("%c", x[i]);
//		}
//	}
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main() {
//	int a, b, d = 0, e = 0, f = 0, g = 0, h = 0, i = 0, l = 0, k = 0, m = 0;
//	char c[100];
//	char arr[17] = { '0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f' };
//	char str[100] = { 0 };
//	char w[100] = "0";
//	scanf("%d %d %s", &a, &b, c);
//	for ( i = 0; c[i] != '\0'; i++) {
//		if (c[i] == '0') {
//			d = 0;
//		}
//		if (c[i] == '1') {
//			d = 1;
//		}
//		if (c[i] == '2') {
//			d = 2;
//		}
//		if (c[i] == '3') {
//			d = 3;
//		}
//		if (c[i] == '4') {
//			d = 4;
//		}
//		if (c[i] == '5') {
//			d = 5;
//		}
//		if (c[i] == '6') {
//			d = 6;
//		}
//		if (c[i] == '7') {
//			d = 7;
//		}
//		if (c[i] == '8') {
//			d = 8;
//		}
//		if (c[i] == '9') {
//			d = 9;
//		}
//		if (c[i] == 'a') {
//			d = 10;
//		}
//		if (c[i] == 'b') {
//			d = 11;
//		}
//		if (c[i] == 'c') {
//			d = 12;
//		}
//		if (c[i] == 'd') {
//			d = 13;
//		}
//		if (c[i] == 'e') {
//			d = 14;
//		}
//		if (c[i] == 'f') {
//			d = 15;
//		}
//		f = f * a;
//		f += d;
//	}
//		h = f;
//		if (a = 16) {
//			printf("%d", f);
//		}
//		if (a != 16) {
//			if (b != 16) {
//				while (f != 0) {
//					k = f % b;
//					f = f / b;
//					e += k * pow(a, l);
//					l++;
//				}
//				printf("%d", e);
//			}
//			else {
//
//				while (f != 0) {
//					k = f % b;
//					f = f / b;
//					l++;
//				}
//				while (l > 0) {
//					m = h % b;
//					h = h / b;
//					str[l - 1] = arr[m];
//					w[l - 1] = str[l - 1];
//					l--;
//				}
//				printf("%s", w);
//			}
//		}
//	return 0;
////}
//#include<stdio.h>
//#include<math.h>
//int main() {
//	int a, b, d,  f = 0, g = 0, i;
//	char x[100], c[100];
//	scanf("%d %d %s", &a, &b, c);
//	d = 0;
//	for (i = 0; c[i] != '\0'; i++) {
//		if (c[i] == '0') {
//			d = 0;
//		}
//		if (c[i] == '1') {
//			d = 1;
//		}
//		if (c[i] == '2') {
//			d = 2;
//		}
//		if (c[i] == '3') {
//			d = 3;
//		}
//		if (c[i] == '4') {
//			d = 4;
//		}
//		if (c[i] == '5') {
//			d = 5;
//		}
//		if (c[i] == '6') {
//			d = 6;
//		}
//		if (c[i] == '7') {
//			d = 7;
//		}
//		if (c[i] == '8') {
//			d = 8;
//		}
//		if (c[i] == '9') {
//			d = 9;
//		}
//		if (c[i] == 'a') {
//			d = 10;
//		}
//		if (c[i] == 'b') {
//			d = 11;
//		}
//		if (c[i] == 'c') {
//			d = 12;
//		}
//		if (c[i] == 'd') {
//			d = 13;
//		}
//		if (c[i] == 'e') {
//			d = 14;
//		}
//		if (c[i] == 'f') {
//			d = 15;
//		}
//		f *= a;
//		f += d;
//	}
//	d = f;
//	for (i = 0; d > 0; i++) {
//		f = d % b;
//		d /= b;
//		{
//			if (f == 0) {
//				x[i] = '0';
//			}
//			if (f == 1) {
//				x[i] = '1';
//			}
//			if (f == 2) {
//				x[i] = '2';
//			}
//			if (f == 3) {
//				x[i] = '3';
//			}
//			if (f == 4) {
//				x[i] = '4';
//			}
//			if (f == 5) {
//				x[i] = '5';
//			}
//			if (f == 6) {
//				x[i] = '6';
//			}
//			if (f == 7) {
//				x[i] = '7';
//			}
//			if (f == 8) {
//				x[i] = '8';
//			}
//			if (f == 9) {
//				x[i] = '9';
//			}
//			if (f == 10) {
//				x[i] = 'a';
//			}
//			if (f == 11) {
//				x[i] = 'b';
//			}
//			if (f == 12) {
//				x[i] = 'c';
//			}
//			if (f == 13) {
//				x[i] = 'd';
//			}
//			if (f == 14) {
//				x[i] = 'e';
//			}
//			if (f == 15) {
//				x[i] = 'f';
//			}}
//	}
//	{
//		for (i = i - 1; i >= 0; i--) {
//			printf("%c", x[i]);
//		}
//	}
//	return 0;
//}

//}
//#include<stdio.h>
//#include<math.h>
//int main() {
//	int a, b, f = 0, g = 0, i;
//	char x[100], c[100];
//	scanf("%d %d %s", &a, &b, c);
//	d = 0;
//	for (i = 0; c[i] != '\0'; i++) {
//		if (c[i] == '0') {
//			d = 0;
//		}
//		if (c[i] == '1') {
//			d = 1;
//		}
//		if (c[i] == '2') {
//			d = 2;
//		}
//		if (c[i] == '3') {
//			d = 3;
//		}
//		if (c[i] == '4') {
//			d = 4;
//		}
//		if (c[i] == '5') {
//			d = 5;
//		}
//		if (c[i] == '6') {
//			d = 6;
//		}
//		if (c[i] == '7') {
//			d = 7;
//		}
//		if (c[i] == '8') {
//			d = 8;
//		}
//		if (c[i] == '9') {
//			d = 9;
//		}
//		if (c[i] == 'a') {
//			d = 10;
//		}
//		if (c[i] == 'b') {
//			d = 11;
//		}
//		if (c[i] == 'c') {
//			d = 12;
//		}
//		if (c[i] == 'd') {
//			d = 13;
//		}
//		if (c[i] == 'e') {
//			d = 14;
//		}
//		if (c[i] == 'f') {
//			d = 15;
//		}
//		f *= a;
//		f += d;
//	}
//	d = f;
//	for (i = 0; d > 0; i++) {
//		f = d % b;
//		d /= b;
//		{
//			if (f == 0) {
//				x[i] = '0';
//			}
//			if (f == 1) {
//				x[i] = '1';
//			}
//			if (f == 2) {
//				x[i] = '2';
//			}
//			if (f == 3) {
//				x[i] = '3';
//			}
//			if (f == 4) {
//				x[i] = '4';
//			}
//			if (f == 5) {
//				x[i] = '5';
//			}
//			if (f == 6) {
//				x[i] = '6';
//			}
//			if (f == 7) {
//				x[i] = '7';
//			}
//			if (f == 8) {
//				x[i] = '8';
//			}
//			if (f == 9) {
//				x[i] = '9';
//			}
//			if (f == 10) {
//				x[i] = 'a';
//			}
//			if (f == 11) {
//				x[i] = 'b';
//			}
//			if (f == 12) {
//				x[i] = 'c';
//			}
//			if (f == 13) {
//				x[i] = 'd';
//			}
//			if (f == 14) {
//				x[i] = 'e';
//			}
//			if (f == 15) {
//				x[i] = 'f';
//			}}
//	}
//	{
//		for (i = i - 1; i >= 0; i--) {
//			printf("%c", x[i]);
//		}
//	}
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	int a = 0, b = 0;
//	int arr[1000] = { 0 };
//	scanf("%d", &a);
//	arr[1] = 1;
//	arr[2] = 2;
//	arr[3] = 4;
//	for (b = 4; b < 1000; b++) {
//		arr[b] = arr[b - 1] + arr[b - 2] + arr[b - 3];
//	}
//	printf("%d", arr[a]);
//	return 0;
//}
//#include<stdio.h>
//#include<math.h>
//int main()
//{
//	int n, seed, a, b, m;
//	scanf("%d%d%d%d%d", &n, &seed, &a, &b, &m);
//	for (int i = 1; i <= n; i++) {
//		seed = (seed * a + b) % m;
//		printf("%d ", seed);
//	}
//	return 0;
//}
//#include<stdio.h>
//int main()
//{
//	int n = 0, i, j, k;
//	int a = 0;
//	int arr[1000];
//	scanf("%d", &n);
//	for (i = 0; i < n; i++) {
//		scanf("%d", &arr[i]);
//	}
//	for (j = 0; j < n - 1; j++) {
//		for (k = 0; k < n - 1 - j; k++) {
//			if (arr[k] > arr[k + 1]) {
//				a = arr[k];
//				arr[k] = arr[k + 1];
//				arr[k + 1] = a;
//			}
//		}
//	}
//	for (i = 0; i < n; i++) {
//		printf("%d ", arr[i]);
//	}
//	return 0;
//}
//#include<stdio.h>
//int main() 
//{
//	int a, b,d=-1;
//	scanf("%d%d", &a, &b);
//	int c[10000];
//	for (int i = 0; i < a; i++) {
//		scanf("%d", &c[i]);
//	}
//	int le = 0, r = a - 1;
//	int m = 0;
//	
//	while (r >= le) {
//		m = (r + le) / 2;
//		if (c[m] > b) {
//			r = m-1;
//		}
//		else if (c[m] < b) {
//			le = m+1;
//		}
//		else if(c[m] = b){
//			printf("%d", m);
//			break;
//		}
//	}
//	if (r < le) {
//		printf("%d",d);
//	}
//	return 0;
//}
#include<stdio.h>
#include<stdlib.h>
int main() 
{
	int seed, n;
	double c = 0, e = 0;
	scanf("%d%d", &seed, &n);
	srand(seed);
	for (long long k = 0; k <= n; k++) {
		e = e + 1.0;
		double x = ((rand() % 1000) + 1000) / 1000;
		double y = (rand() % 1000) / 1000;
		if (x*y<=1) {
			c = c + 1.0;
		}
	}
	float d = c / e;
	printf("%f", d);
	return 0;
}